#include<stdio>
#include<conio>
void main()
{
    printf("hello world");
    return 0;
}